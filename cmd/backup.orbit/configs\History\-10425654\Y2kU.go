package cmd

import (
	"testing"

	"github.com/spf13/cobra"
)

func TestLoadFunc(t *testing.T) {
	// 创建一个测试用的 cobra 命令
	cmd := &cobra.Command{
		Use: "test",
		RunE: func(cmd *cobra.Command, args []string) error {
			return loadFunc()
		},
	}

	// 添加 load flag 到测试命令
	flags := []string{
		"save",
		"read",
		"load",
	}

	for _, flag := range flags {
		cmd.Flags().StringVar(&flag, "load", "default_value", "test load flag")
	}

	// 测试用例：设置 flag 值并执行
	tests := []struct {
		name    string
		loadArg string
		wantErr bool
	}{
		{"with default value", "default_value", false},
		{"with custom value", "custom_value", false},
		{"with empty value", "", false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// 设置命令行参数
			cmd.SetArgs([]string{"--load", tt.loadArg})

			// 执行命令
			err := cmd.Execute()
			if (err != nil) != tt.wantErr {
				t.Errorf("loadFunc() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}
