package cmd

import (
	"testing"
)

func TestLoadFunc(t *testing.T) {
}
