package golangtest

import (
	"fmt"
	"os"
)

func main() {

	tempDir := os.Getenv("TEMP")
	fmt.Println(tempDir)

}
