#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
文件重命名脚本
使用txt文件中的名称来重命名指定文件夹中的文件
"""

import os
import sys
import random
from pathlib import Path

def read_names_from_file(names_file):
    """
    从txt文件中读取名称列表
    
    Args:
        names_file (str): 包含名称的txt文件路径
    
    Returns:
        list: 名称列表
    """
    try:
        with open(names_file, 'r', encoding='utf-8') as f:
            names = [line.strip() for line in f.readlines() if line.strip()]
        return names
    except FileNotFoundError:
        print(f"错误: 找不到文件 '{names_file}'")
        return []
    except Exception as e:
        print(f"读取文件时出错: {e}")
        return []

def remove_used_names_from_file(names_file, used_names):
    """
    从txt文件中删除已使用的名称
    
    Args:
        names_file (str): 包含名称的txt文件路径
        used_names (list): 已使用的名称列表
    """
    try:
        # 读取当前文件中的所有名称
        with open(names_file, 'r', encoding='utf-8') as f:
            all_names = [line.strip() for line in f.readlines() if line.strip()]
        
        # 移除已使用的名称
        remaining_names = [name for name in all_names if name not in used_names]
        
        # 将剩余名称写回文件
        with open(names_file, 'w', encoding='utf-8') as f:
            for name in remaining_names:
                f.write(name + '\n')
        
        print(f"已从文件中删除 {len(used_names)} 个已使用的名称")
        print(f"文件中剩余 {len(remaining_names)} 个名称")
        
    except Exception as e:
        print(f"删除已使用名称时出错: {e}")

def get_files_to_rename(directory):
    """
    获取指定目录中的所有文件
    
    Args:
        directory (str): 目标目录路径
    
    Returns:
        list: 文件路径列表
    """
    try:
        path = Path(directory)
        if not path.exists():
            print(f"错误: 目录 '{directory}' 不存在")
            return []
        
        files = [f for f in path.iterdir() if f.is_file()]
        return files
    except Exception as e:
        print(f"读取目录时出错: {e}")
        return []

def sanitize_filename(name):
    """
    清理文件名，移除不允许的字符
    
    Args:
        name (str): 原始名称
    
    Returns:
        str: 清理后的文件名
    """
    # Windows和其他系统不允许的字符
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        name = name.replace(char, '_')
    
    # 移除前后空格和点
    name = name.strip('. ')
    
    return name

def rename_files(names_file, target_directory, mode='sequential', preview=True):
    """
    重命名文件
    
    Args:
        names_file (str): 包含名称的txt文件路径
        target_directory (str): 目标目录路径
        mode (str): 重命名模式 ('sequential' 或 'random')
        preview (bool): 是否只预览，不实际重命名
    """
    # 读取名称列表
    names = read_names_from_file(names_file)
    if not names:
        print("没有可用的名称")
        return
    
    # 获取要重命名的文件
    files = get_files_to_rename(target_directory)
    if not files:
        print("没有找到要重命名的文件")
        return
    
    print(f"找到 {len(files)} 个文件，{len(names)} 个名称")
    
    if len(files) > len(names):
        print(f"警告: 文件数量({len(files)})超过名称数量({len(names)})")
        print("部分文件可能会使用重复的名称")
    
    # 准备重命名操作
    rename_operations = []
    used_names = set()
    
    if mode == 'random':
        available_names = names.copy()
        random.shuffle(available_names)
    else:
        available_names = names
    
    for i, file_path in enumerate(files):
        # 获取新名称
        if i < len(available_names):
            new_name = available_names[i]
        else:
            # 如果名称不够，循环使用或添加数字后缀
            base_name = available_names[i % len(available_names)]
            suffix = i // len(available_names) + 1
            new_name = f"{base_name}_{suffix}"
        
        # 清理文件名
        clean_name = sanitize_filename(new_name)
        
        # 确保名称唯一
        original_clean_name = clean_name
        counter = 1
        while clean_name in used_names:
            clean_name = f"{original_clean_name}_{counter}"
            counter += 1
        used_names.add(clean_name)
        
        # 保持原文件扩展名
        file_extension = file_path.suffix
        new_filename = clean_name + file_extension
        new_path = file_path.parent / new_filename
        
        rename_operations.append((file_path, new_path, new_name))
    
    # 显示重命名预览
    print("\n重命名预览:")
    print("-" * 80)
    for old_path, new_path, original_name in rename_operations:
        print(f"{old_path.name} -> {new_path.name}")
        print(f"  原名称: {original_name}")
    print("-" * 80)
    
    if preview:
        print("\n这是预览模式，文件未被实际重命名。")
        response = input("是否执行重命名? (y/N): ").strip().lower()
        if response != 'y':
            print("操作已取消")
            return
    
    # 执行重命名
    success_count = 0
    for old_path, new_path, original_name in rename_operations:
        try:
            old_path.rename(new_path)
            success_count += 1
            print(f"✓ 重命名成功: {old_path.name} -> {new_path.name}")
        except Exception as e:
            print(f"✗ 重命名失败: {old_path.name} -> {new_path.name}")
            print(f"  错误: {e}")
    
    print(f"\n重命名完成: {success_count}/{len(rename_operations)} 个文件成功重命名")

def main():
    """主函数"""
    print("文件重命名工具")
    print("=" * 50)
    
    # 获取用户输入
    if len(sys.argv) > 1:
        names_file = sys.argv[1]
    else:
        names_file = input("请输入包含名称的txt文件路径 (默认: names.txt): ").strip()
        if not names_file:
            names_file = "names.txt"
    
    if len(sys.argv) > 2:
        target_directory = sys.argv[2]
    else:
        target_directory = input("请输入要重命名文件的目录路径 (默认: 当前目录): ").strip()
        if not target_directory:
            target_directory = "."
    
    # 选择重命名模式
    print("\n重命名模式:")
    print("1. 顺序模式 (按txt文件中的顺序)")
    print("2. 随机模式 (随机选择名称)")
    
    mode_choice = input("请选择模式 (1/2, 默认: 1): ").strip()
    mode = 'random' if mode_choice == '2' else 'sequential'
    
    # 执行重命名
    rename_files(names_file, target_directory, mode, preview=True)

if __name__ == "__main__":
    main()
