package main

import (
	"fmt"
	"os"
	"path/filepath"
)

func main() {
	tempDir := os.Getenv("TEMP")
	fmt.Println(tempDir)

	file, err := filepath.Rel(tempDir, "filepath.Join(tempDir, )")
	if err != nil {
		return
	}

	fmt.Println(file)

}
