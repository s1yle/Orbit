package cmd

import (
	"os"
)

func findFileByPath(path string) (*os.File, error) {

	srcFile, err := os.Open(path)
	if err != nil {
		return srcFile, err
	}

	return srcFile, err
}
