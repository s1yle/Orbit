package cmd

import (
	"testing"
)

func TestLoadFunc(t *testing.T) {
	// if err := loadFunc(); err != nil {
	// 	t.Errorf("loadFunc() error = %v", err)
	// }

}
