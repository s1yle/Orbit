# 文件重命名工具

这是一个Python脚本，可以使用txt文件中的名称来重命名指定文件夹中的文件。

## 功能特点

- 从txt文件中读取名称列表
- 支持顺序和随机两种重命名模式
- 自动清理文件名中的非法字符
- 保持原文件的扩展名
- 预览模式，确认后再执行重命名
- 处理名称重复和数量不匹配的情况
- 详细的错误处理和用户反馈

## 使用方法

### 方法1: 交互式运行
```bash
python file_renamer.py
```
然后按提示输入：
- txt文件路径（默认：names.txt）
- 目标目录路径（默认：当前目录）
- 重命名模式（顺序/随机）

### 方法2: 命令行参数
```bash
python file_renamer.py [names_file] [target_directory]
```

例如：
```bash
python file_renamer.py names.txt ./test_files
```

## 重命名模式

1. **顺序模式**: 按照txt文件中名称的顺序依次重命名
2. **随机模式**: 随机选择txt文件中的名称进行重命名

## 安全特性

- 预览模式：显示重命名预览，需要用户确认后才执行
- 文件名清理：自动移除Windows和其他系统不允许的字符
- 重复处理：自动处理重复名称，添加数字后缀
- 扩展名保持：保持原文件的扩展名不变

## 示例

假设你有以下文件需要重命名：
```
photo1.jpg
photo2.jpg
document.pdf
```

使用names.txt中的名称，可能会重命名为：
```
Study Hall Blueprints.jpg
Nocturnal Productivity.jpg
Light on Draft Paper.pdf
```

## 注意事项

- 确保txt文件使用UTF-8编码
- 每行一个名称
- 脚本会自动处理文件名中的特殊字符
- 建议先在测试目录中试用
