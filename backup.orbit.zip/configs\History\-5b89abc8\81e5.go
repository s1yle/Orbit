package cmd

import (
	"archive/zip"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"

	"github.com/spf13/cobra"
)

type SoftwareItem struct {
	Name    string `json:"name"`
	Version string `json:"version"`
}

// loadCmd represents the load command
var loadCmd = &cobra.Command{
	Use:   "load",
	Short: "Restore software configurations from a backup file",
	Long: `Load a backup file (.orbit) and:
- Display software list that needs to be installed
- Restore configuration files to their proper locations`,
	Run: func(cmd *cobra.Command, args []string) {
		if len(args) == 0 {
			fmt.Println("Error: Please provide the path to the .orbit backup file")
			os.Exit(1)
		}

		backupPath := args[0]
		if err := restoreBackup(backupPath); err != nil {
			fmt.Printf("Error restoring backup: %v\n", err)
			os.Exit(1)
		}
	},
}

func extractBackup(backupPath string) (string, error) {
	tempDir, err := os.MkdirTemp("", "orbit-restore")
	if err != nil {
		return "", err
	}

	zipReader, err := zip.OpenReader(backupPath)
	if err != nil {
		os.RemoveAll(tempDir)
		return "", err
	}
	defer zipReader.Close()

	for _, file := range zipReader.File {
		filePath := filepath.Join(tempDir, file.Name)

		if file.FileInfo().IsDir() {
			os.MkdirAll(filePath, file.Mode())
			continue
		}

		if err := os.MkdirAll(filepath.Dir(filePath), 0755); err != nil {
			return "", err
		}

		dstFile, err := os.OpenFile(filePath, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, file.Mode())
		if err != nil {
			return "", err
		}
		defer dstFile.Close()

		srcFile, err := file.Open()
		if err != nil {
			return "", err
		}
		defer srcFile.Close()

		if _, err := io.Copy(dstFile, srcFile); err != nil {
			return "", err
		}
	}

	return tempDir, nil
}

func displaySoftwareList(tempDir string) error {
	softwareFile := filepath.Join(tempDir, "software-list.json")
	data, err := os.ReadFile(softwareFile)
	if err != nil {
		return err
	}

	// Try to parse as JSON array first
	var softwareList []SoftwareItem
	if err := json.Unmarshal(data, &softwareList); err == nil {
		fmt.Println("Software that needs to be installed:")
		fmt.Println("====================================")
		for _, item := range softwareList {
			fmt.Printf("- %s (Version: %s)\n", item.Name, item.Version)
		}
		return nil
	}

	// If JSON parsing fails, display raw content
	fmt.Println("Installed software list:")
	fmt.Println("========================")
	fmt.Println(string(data))
	return nil
}

func restoreConfigFiles(tempDir string) error {
	configsDir := filepath.Join(tempDir, "configs")
	if _, err := os.Stat(configsDir); os.IsNotExist(err) {
		return nil // No configs to restore
	}

	// Restore VS Code settings
	vscodeSettingsSrc := filepath.Join(configsDir, "vscode-settings.json")
	if _, err := os.Stat(vscodeSettingsSrc); err == nil {
		vscodeSettingsDest := filepath.Join(os.Getenv("APPDATA"), "Code", "User", "settings.json")

		// Create destination directory if it doesn't exist
		if err := os.MkdirAll(filepath.Dir(vscodeSettingsDest), 0755); err != nil {
			return err
		}

		srcFile, err := os.Open(vscodeSettingsSrc)
		if err != nil {
			return err
		}
		defer srcFile.Close()

		destFile, err := os.Create(vscodeSettingsDest)
		if err != nil {
			return err
		}
		defer destFile.Close()

		if _, err := io.Copy(destFile, srcFile); err != nil {
			return err
		}
		fmt.Printf("Restored VS Code settings to: %s\n", vscodeSettingsDest)
	}

	// Add more config file restorations as needed
	return nil
}

func restoreBackup(backupPath string) error {
	if !strings.HasSuffix(backupPath, ".orbit") {
		return fmt.Errorf("file must have .orbit extension")
	}

	if _, err := os.Stat(backupPath); os.IsNotExist(err) {
		return fmt.Errorf("backup file does not exist: %s", backupPath)
	}

	// Extract backup
	tempDir, err := extractBackup(backupPath)
	if err != nil {
		return err
	}
	defer os.RemoveAll(tempDir)

	// Display manifest information
	manifestFile := filepath.Join(tempDir, "manifest.json")
	if data, err := os.ReadFile(manifestFile); err == nil {
		var manifest Manifest
		if err := json.Unmarshal(data, &manifest); err == nil {
			fmt.Printf("Backup created on: %s\n", manifest.Timestamp)
			fmt.Printf("Original system: %s %s\n", manifest.OS, manifest.Arch)
			fmt.Printf("Original user: %s@%s\n", manifest.Username, manifest.Hostname)
			fmt.Println()
		}
	}

	// Display software list
	if err := displaySoftwareList(tempDir); err != nil {
		fmt.Printf("Warning: Could not read software list: %v\n", err)
	}
	fmt.Println()

	// Restore config files
	if err := restoreConfigFiles(tempDir); err != nil {
		fmt.Printf("Warning: Could not restore all config files: %v\n", err)
	} else {
		fmt.Println("Configuration files restored successfully")
	}

	return nil
}

func init() {
	rootCmd.AddCommand(loadCmd)
}
