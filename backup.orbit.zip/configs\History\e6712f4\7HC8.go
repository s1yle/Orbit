package main

import (
	"fmt"

	"github.com/spf13/cobra"
)

func main() {
	fmt.Println("Hello world")
	cobra.CompDebugln("1", false)
}
