package cmd

import (
	"archive/zip"
	"fmt"

	//"io/ioutil"
	//"log"
	"github.com/spf13/cobra"
)

func readFromOrbitFile(filePath string) error {
	fmt.Println("输入的文件路径：", filePath)
	r, err := zip.OpenReader(filePath)
	if err != nil {
		fmt.Println("Error opening .orbit file:", err)
		return err
	}
	defer r.Close()

	fmt.Println("Files in the .orbit archive:", r)

	for i, f := range r.File {
		fmt.Println(i)
		fmt.Printf("Contents of %s:\n", f.Name)
	}

	return nil
}

var readOrbitFile = &cobra.Command{
	Use:   "read-orbit [name.orbit]",
	Short: "Read configuration from an .orbit file",
	Args:  cobra.MaximumNArgs(1),
	Run: func(cmd *cobra.Command, args []string) {
		// 参数检查
		if len(args) < 1 {
			fmt.Println("Please provide the .orbit file name.")
			return
		}

		orbitFile := args[0] + ".orbit"

		fmt.Printf("Reading .orbit file: %s\n", orbitFile)
		err := readFromOrbitFile(orbitFile)
		if err != nil {
			fmt.Errorf("failed to read .orbit file: %v", err)
		}

		fmt.Println("Read operation completed.")
	},
}

func init() {
	rootCmd.AddCommand(readOrbitFile)
}
