#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
随机文件重命名工具
从指定的txt文件中提取字符，用这些字符随机生成新的文件名来重命名指定目录中的文件
"""

import os
import random
import string
import argparse
import sys
from pathlib import Path


def read_text_file(file_path):
    """读取txt文件并提取所有字符"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        # 移除空白字符，只保留可见字符
        chars = ''.join(content.split())
        if not chars:
            print(f"警告: 文件 {file_path} 中没有找到可用字符")
            return None
        return chars
    except FileNotFoundError:
        print(f"错误: 找不到文件 {file_path}")
        return None
    except Exception as e:
        print(f"错误: 读取文件时出现问题 - {e}")
        return None


def generate_random_name(chars, length=8, keep_extension=True, original_name=""):
    """使用提供的字符生成随机文件名"""
    if not chars:
        return original_name
    
    # 生成随机名称
    random_name = ''.join(random.choice(chars) for _ in range(length))
    
    if keep_extension and '.' in original_name:
        # 保留原始文件扩展名
        extension = Path(original_name).suffix
        return random_name + extension
    else:
        return random_name


def rename_files(directory, txt_file, name_length=8, dry_run=False):
    """重命名指定目录中的文件"""
    # 读取字符源文件
    chars = read_text_file(txt_file)
    if not chars:
        return False
    
    print(f"从文件 {txt_file} 中读取到 {len(set(chars))} 个不同字符")
    print(f"字符集预览: {set(chars)}")
    
    # 检查目录是否存在
    if not os.path.isdir(directory):
        print(f"错误: 目录 {directory} 不存在")
        return False
    
    # 获取目录中的所有文件
    files = [f for f in os.listdir(directory) if os.path.isfile(os.path.join(directory, f))]
    
    if not files:
        print(f"目录 {directory} 中没有找到文件")
        return False
    
    print(f"\n找到 {len(files)} 个文件需要重命名")
    
    renamed_count = 0
    failed_count = 0
    
    for filename in files:
        old_path = os.path.join(directory, filename)
        new_filename = generate_random_name(chars, name_length, True, filename)
        new_path = os.path.join(directory, new_filename)
        
        # 避免文件名冲突
        counter = 1
        original_new_filename = new_filename
        while os.path.exists(new_path) and new_path != old_path:
            name_part = Path(original_new_filename).stem
            extension = Path(original_new_filename).suffix
            new_filename = f"{name_part}_{counter}{extension}"
            new_path = os.path.join(directory, new_filename)
            counter += 1
        
        if dry_run:
            print(f"[预览] {filename} -> {new_filename}")
        else:
            try:
                os.rename(old_path, new_path)
                print(f"✓ {filename} -> {new_filename}")
                renamed_count += 1
            except Exception as e:
                print(f"✗ 重命名失败 {filename}: {e}")
                failed_count += 1
    
    if not dry_run:
        print(f"\n重命名完成: 成功 {renamed_count} 个, 失败 {failed_count} 个")
    
    return True


def main():
    parser = argparse.ArgumentParser(description='使用txt文件中的字符随机重命名文件')
    parser.add_argument('txt_file', help='包含字符的txt文件路径')
    parser.add_argument('directory', help='要重命名文件的目录路径')
    parser.add_argument('-l', '--length', type=int, default=8, help='生成的文件名长度 (默认: 8)')
    parser.add_argument('-d', '--dry-run', action='store_true', help='预览模式，不实际重命名文件')
    parser.add_argument('-y', '--yes', action='store_true', help='跳过确认提示')
    
    args = parser.parse_args()
    
    # 验证输入
    if not os.path.isfile(args.txt_file):
        print(f"错误: txt文件 {args.txt_file} 不存在")
        sys.exit(1)
    
    if not os.path.isdir(args.directory):
        print(f"错误: 目录 {args.directory} 不存在")
        sys.exit(1)
    
    # 显示操作信息
    print("=" * 50)
    print("随机文件重命名工具")
    print("=" * 50)
    print(f"字符源文件: {args.txt_file}")
    print(f"目标目录: {args.directory}")
    print(f"文件名长度: {args.length}")
    print(f"预览模式: {'是' if args.dry_run else '否'}")
    print("=" * 50)
    
    # 确认操作
    if not args.dry_run and not args.yes:
        confirm = input("\n确定要继续吗? (y/N): ").lower().strip()
        if confirm not in ['y', 'yes', '是']:
            print("操作已取消")
            sys.exit(0)
    
    # 执行重命名
    success = rename_files(args.directory, args.txt_file, args.length, args.dry_run)
    
    if success:
        if args.dry_run:
            print("\n预览完成！使用 --yes 参数可直接执行重命名")
        else:
            print("\n重命名操作完成！")
    else:
        print("\n操作失败！")
        sys.exit(1)


if __name__ == "__main__":
    main()
