package main

import (
	"fmt"
	"os"
	"path/filepath"
)

func main() {
	tempDir := os.Getenv("TEMP")
	fmt.Println(tempDir)

	file, err := filepath.Rel(tempDir, "13")
	if err != nil {
		return
	}

	fmt.Println(file)

}
