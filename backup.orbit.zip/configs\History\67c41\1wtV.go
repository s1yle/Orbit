package cmd

import (
	"archive/zip"
	"encoding/json"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"runtime"
	"time"

	"github.com/spf13/cobra"
)

func saveVscode(tempDir string) error {
	fmt.Println("[info] --- 正在保存Vscode配置文件...")

	UsersFile := filepath.Join(CodeConfigDir, "User")
	WorkspacesFile := filepath.Join(CodeConfigDir, "Workspaces")
	dirs := []string{UsersFile, WorkspacesFile}
	// fmt.Println("dirs: ", dirs)
	err := os.MkdirAll(filepath.Join(tempDir, "configs"), 0644)
	if err != nil {
		return err
	}

	// configsPath, err := configsDir.ReadDir(0)
	// fmt.Println("--------- configsPath: ", configsPath)
	// if err != nil {
	// 	return err
	// }

	for _, dir := range dirs {
		filepath.Walk(dir, func(path string, info fs.FileInfo, err error) error {
			if err != nil {
				return err
			}
			relPath, _ := filepath.Rel(dir, path)                // 获取相对路径
			dstPath := filepath.Join(filepath.Dir(dir), relPath) // 目标路径

			if info.IsDir() {
				err = os.MkdirAll(dstPath, os.ModePerm) // 创建目录
				if err != nil {
					return err
				}
				// fmt.Println("dir: ", dstPath)
			} else {
				err = copyFile(path, dstPath) // 复制文件
				if err != nil {
					return err
				}
				// fmt.Println(path)
			}
			return nil
		})
	}

	return nil
}

// 获取系统信息到manifest 中并转换为 byte array
func convertMeniToJson() ([]byte, error) {
	var jsonData []byte // 获取系统信息

	hostname, err := os.Hostname()
	if err != nil {
		fmt.Printf("获取主机名失败: %v\n", err)
		return jsonData, err
	}

	// 获取当前用户名
	// 注意：os.UserHomeDir() 不能直接获取用户名，这里使用另一种方式
	username, err := getWinUserName()
	if err != nil {
		return jsonData, err
	}

	// 创建manifest.json文件
	var manifestContent Manifest = Manifest{
		Timestamp: time.Now().Format(time.RFC3339),
		OS:        runtime.GOOS,
		Arch:      runtime.GOARCH,
		Hostname:  hostname,
		Username:  username,
	}

	jsonData, err = json.MarshalIndent(manifestContent, "", "  ")
	if err != nil {
		return jsonData, err
	}

	return jsonData, nil
}

// @param tempDir C:\Users\mmili\AppData\Local\Temp\test_orbit-backup
func createOrbitZip(tempDir string) error {

	backupFile, err := os.Create("backup.orbit")
	if err != nil {
		return err
	}
	defer backupFile.Close()

	zipWriter := zip.NewWriter(backupFile)
	defer zipWriter.Close()

	fmt.Println("---  正在将文件写入 orbit包")
	err = filepath.Walk(tempDir, func(path string, info fs.FileInfo, err error) error {
		if err != nil {
			return err
		}

		relpath, err := filepath.Rel(tempDir, path)
		if err != nil {
			return err
		}

		zipFile, err := zipWriter.Create(relpath)
		if err != nil {
			return err
		}

		file, err := os.Open(path)
		if err != nil {
			return err
		}
		defer file.Close()

		fmt.Println("-----  ", file.Name())
		_, err = io.Copy(zipFile, file)
		return err
	})

	return err
}

func createBackup() error {

	// @param tempDir C:\Users\mmili\AppData\Local\Temp\test_orbit-backup
	tempDir, err := os.MkdirTemp("", "test_orbit-backup")
	fmt.Printf("[info] --- 成功创建临时目录：%v\n", tempDir)
	if err != nil {
		return err
	}
	defer os.RemoveAll(tempDir)

	//保存vscode配置文件
	if err := saveVscode(tempDir); err != nil {
		return err
	}

	//获取系统信息写入进manifest.json
	jsonData, err := convertMeniToJson()
	if err != nil {
		return err
	}
	manifestPath := filepath.Join(tempDir, "manifest.json")
	if err := os.WriteFile(manifestPath, jsonData, 0644); err != nil {
		return err
	}
	fmt.Printf("[info] --- 创建manifest.json文件\n")

	//压缩成.orbit格式
	err = createOrbitZip(tempDir)
	if err != nil {
		return err
	}

	return err
}

var save = &cobra.Command{
	Use:   "save",
	Short: "Create a backup of software configurations and installed software list",
	Long: `Create a compressed backup file (.orbit) containing:
	- manifest.json with timestamp and system information
	- software-list.json with installed software
	- configs/ folder with configuration files`,
	Run: func(cmd *cobra.Command, args []string) {
		if err := createBackup(); err != nil {
			fmt.Printf("[error] ---  %v", err)
			os.Exit(1)
		}
	},
}

func init() {
	rootCmd.AddCommand(save)
}
