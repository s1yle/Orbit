# PCIeLeech WiFi FPGA Project Guide

This document provides essential context for AI agents working with this PCIe FPGA implementation.

## Project Overview
This is a modified version of the PCIeLeech FPGA project that emulates a wireless network card. The project uses Xilinx 7-series FPGA technology and implements PCIe Gen2 functionality.

## Key Architecture Components

### PCIe Core Implementation
- Main PCIe core implementation is in `pcie_7x/pcie_7x_0_pcie_top.v`
- Uses Xilinx PCIe IP core with customized wrapper
- Critical parameters and capabilities are defined in module parameters
- Implements PCIe transaction layer, data link layer, and physical layer interfaces

### Key Module Structure
1. **PCIe Top Module**: Main wrapper integrating all components
2. **AXI Basic Top**: Handles AXI transaction interface
3. **PIPE Interface**: Manages physical interface pipeline
4. **Configuration Space**: Custom implementation removing shadow config space

## Important Development Workflows

### FPGA Build Process
1. Use provided `.bat` files for generation:
   - `generate-100T.bat` for 100T variant
   - `generate-squirrel.bat` for squirrel variant
   - Others for different FPGA targets
2. Uses Vivado TCL scripts:
   - `vivado_generate_project_*.tcl` for project generation
   - `vivado_build.tcl` for building

### PCIe Configuration
The project requires careful configuration of PCIe capability registers. Key files/parameters:
- Device capabilities in module parameters
- PCIe configuration space implementation
- Transaction layer packet handling

## Project-Specific Patterns

### Parameter Configuration Pattern
```verilog
parameter [11:0] AER_BASE_PTR = 12'h140,
parameter        AER_CAP_ECRC_CHECK_CAPABLE = "FALSE",
```
All PCIe capabilities should be configured through parameters at the top level.

### Register Access Pattern
The project uses direct register access for PCIe configuration space rather than shadow registers.

## Integration Points

### PCIe Interface
- PIPE interface signals (`pipe_*`) for physical layer
- Transaction layer signals (`trn_*`) for packet handling
- Configuration space signals (`cfg_*`) for PCIe config access

### External Dependencies
1. Xilinx PCIe IP core
2. Vivado tools for synthesis and implementation
3. FPGA board-specific constraints

## Common Tasks

### Adding New PCIe Capabilities
1. Define new parameters in top module
2. Implement capability registers in configuration space
3. Add necessary logic in transaction layer if required
4. Update build constraints if needed

### Debugging Guidance
- Use Vivado ILA for signal tracing
- Monitor PCIe training status through `pl_*` signals
- Check configuration space access through `cfg_*` signals

## Key Files
- `pcie_7x_0_pcie_top.v`: Main PCIe implementation
- `vivado_build.tcl`: Build script
- `*.bat`: Generation scripts for different targets
