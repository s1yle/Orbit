package cmd

import (
	"fmt"
	"io"
	"io/fs"
	"os"
	"os/user"
	"path/filepath"
)

func WalkFromDir(tempDir string) {

	fmt.Println("---  正在将文件写入 orbit包")
	err := filepath.Walk(tempDir, func(path string, info fs.FileInfo, err error) error {
		if err != nil {
			return err
		}

		relpath, err := filepath.Rel(tempDir, path)
		if err != nil {
			return err
		}

		// 如果是目录，创建目录条目并返回
		if info.IsDir() {
			// 为目录创建条目（以斜杠结尾）
			_, err := zipWriter.Create(relpath + "/")
			if err != nil {
				return err
			}
			return nil
		}

		// 如果是文件，创建文件条目并复制内容
		zipFile, err := zipWriter.Create(relpath)
		if err != nil {
			return err
		}

		file, err := os.Open(path)
		if err != nil {
			return err
		}
		defer file.Close()

		fmt.Println("-----  ", file.Name())
		_, err = io.Copy(zipFile, file)
		return err
	})
}

func copyFile(src, dst string) error {
	srcFile, err := os.Open(src)
	if err != nil {
		fmt.Println("出现错误，", err)
		return err
	}
	defer srcFile.Close()

	dstFile, err := os.Create(dst)
	if err != nil {
		fmt.Println("出现错误，", err)
		return err
	}
	defer dstFile.Close()

	io.Copy(dstFile, srcFile) // 复制文件内容

	return nil
}

func findFileByPath(path string) (*os.File, error) {

	srcFile, err := os.Open(path)
	if err != nil {
		return srcFile, err
	}

	return srcFile, err
}

func getWinUserName() (string, error) {

	user, err := user.Current()
	if err != nil {
		return "unknown", err
	}

	return user.Name, nil
}

func getWinUserName2() (string, error) {
	var username string

	_, err := os.UserHomeDir()
	if err != nil {
		username = "unknown" // 如果获取失败，使用默认值
	} else {
		// 这是一个简单的方法，实际上可能需要更复杂的逻辑来提取用户名
		// 例如在Unix系统上，可以从环境变量 $USER 获取
		username = os.Getenv("USER")
		if username == "" {
			username = "unknown"
		}
	}

	return username, err
}
