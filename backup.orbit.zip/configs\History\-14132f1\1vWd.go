package main

import (
	"Orbit/cmd"
	"fmt"
)

func main() {
	fmt.Println("Hello world")
	cmd.Execute()
}
