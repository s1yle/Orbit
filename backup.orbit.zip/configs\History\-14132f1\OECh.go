package main

import (
	"Orbit/cmd"
)

func main() {

	cmd.Execute()
}
