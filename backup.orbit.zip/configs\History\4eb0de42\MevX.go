package cmd

import (
	"archive/zip"
	"fmt"
	"io/fs"
	"io/ioutil"
	"path/filepath"

	//"io/ioutil"
	//"log"
	"github.com/spf13/cobra"
)

func readFromOrbitFile(filePath string) error {
	fmt.Println("输入的文件路径：", filePath)
	r, err := zip.OpenReader(filePath)
	if err != nil {
		fmt.Println("Error opening .orbit file:", err)
		return err
	}
	defer r.Close()

	err = filepath.Walk(r, func(path string, info fs.FileInfo, err error) error {
		if err != nil {
			return err
		}

		if info.IsDir() {

			//读取configs目录下的vscode-settings.json文件
			if info.Name() == "configs" {
				fmt.Println("查找到configs目录")
				for _, f := range r.File {
					if f.Name == "vscode-settings.json" {
						fmt.Println("查找到vscode-settings.json文件")
						// 读取文件内容
						rc, err := f.Open()
						if err != nil {
							return err
						}
						defer rc.Close()

						// 读取文件内容
						content, err := ioutil.ReadAll(rc)
						if err != nil {
							return err
						}
						fmt.Printf("File content: %s\n", content)
					}
				}
			}

		}

		return nil
	})

	return nil
}

var readOrbitFile = &cobra.Command{
	Use:   "read-orbit [name.orbit]",
	Short: "Read configuration from an .orbit file",
	Args:  cobra.MaximumNArgs(1),
	Run: func(cmd *cobra.Command, args []string) {
		// 参数检查
		if len(args) < 1 {
			fmt.Println("Please provide the .orbit file name.")
			return
		}

		orbitFile := args[0]

		fmt.Printf("Reading .orbit file: %s\n", orbitFile)
		err := readFromOrbitFile(orbitFile)
		if err != nil {
			fmt.Errorf("failed to read .orbit file: %v", err)
		}

		fmt.Println("Read operation completed.")
	},
}

func init() {
	rootCmd.AddCommand(readOrbitFile)
}
