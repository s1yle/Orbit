package main

import (
	"fmt"
	"os"
	"path/filepath"
)

func main() {
	tempDir := os.Getenv("TEMP")
	dataDir := os.Getenv("APPDATA")
	fmt.Println(tempDir)
	fmt.Println(dataDir)

	file, err := filepath.Rel(tempDir, dataDir)
	if err != nil {
		return
	}

	fmt.Println(file)

	path := "C:\Users\mmili\AppData\Roaming\Code\User"
	filepath.Dir(path)

}
